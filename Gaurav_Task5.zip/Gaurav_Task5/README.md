This project is a simple Laundry Service landing page built using HTML and CSS. 
It includes a responsive navigation bar with a logo, navigation links, and a 
username section. The hero section contains a heading, a short description, a 
call-to-action button, and a laundry-related image. The layout is created using 
CSS display: inline-block without using Flexbox, as required by the assignment.

How to Run
1. Download or clone the project.
2. Open the project folder.
3. Ensure the following files are in the same directory:
   - index.html
   - style.css
4. Double-click index.html or open it with any web browser.
5. The Laundry Service landing page will be displayed.
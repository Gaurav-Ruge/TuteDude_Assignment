Thala 7 Sneaker Store

A simple responsive sneaker store website created as part of the TuteDude CSS 
Mini Project – Thala 7 Sneaker Store.

The project is built using only HTML and CSS. All the required sections are 
included on a single HTML page.

Project Overview

The website represents an online sneaker store inspired by the provided project
reference.

It includes:

Landing/Home section
Navigation bar
Hero section
Service overview section
Product display section
Product image gallery
Shopping cart section
Order summary
Coupon section
Checkout/payment section
Responsive design
Sticky navigation bar
Technologies Used
HTML5
CSS3

No JavaScript or external frameworks are used.

How to Run
Download or clone the project.
Open the project folder.
Make sure the image files are inside the images folder.
Open index.html in a web browser.
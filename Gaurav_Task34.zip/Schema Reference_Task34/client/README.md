# Task 34 - React Frontend

## Overview
This React frontend connects to the Express/Mongoose backend in the `server` folder.

## Features
- Form for adding users
- Form for adding posts
- Sends POST requests to the backend
- Fetches and displays posts
- Displays each post with the linked user's name and email
- Refresh button
- Loading and error messages

## Run

```text
cd client
npm install
```

Optional: copy `.env.example` to `.env` and set the API URL.

Then:

```text
npm start
```

The Vite app normally runs at `http://localhost:5173`.

The Express API should be running at `http://localhost:5000`.

This project demonstrates the use of CSS Units, the CSS Box Model, and Font styling 
to create a simple responsive webpage. The page contains a centered image with a 
gradient button below it. The layout is built using viewport units (vw and vh) and 
proper box-sizing without using Flexbox, positioning, or overflow properties, 
following the assignment requirements.

How to Run
1. Download or clone this repository.
2. Make sure index.html and style.css are in the same folder.
3. If using a local image, place it in the same folder and update the image path in index.html.
4. Open index.html in any modern web browser (Google Chrome, Microsoft Edge, Firefox, etc.).
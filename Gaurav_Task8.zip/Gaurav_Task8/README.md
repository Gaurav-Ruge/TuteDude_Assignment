This project is a responsive Laundry Services landing page built using HTML and CSS. It 
includes a navigation bar, hero section, and a hamburger menu for mobile devices. The 
navigation menu is visible on desktop and tablet screens, while a hamburger icon is 
shown only on mobile screens.


How to Run

1. Download or clone this repository.
2. Open the project folder.
3. Open index.html in any web browser.
4. Resize the browser window to test the desktop, tablet, and mobile layouts.
5. In mobile view, click the hamburger icon to open the navigation menu.


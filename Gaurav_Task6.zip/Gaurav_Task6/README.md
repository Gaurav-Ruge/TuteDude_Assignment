Laundry Mart Login Page
Project Description
This is a simple login page created using HTML and CSS. The page has two sections: an image section on the left and a login form on the right.
I used Flexbox to create the two-column layout and to center the content inside each section. The login form uses a column Flexbox layout so that the heading, input fields, links, and button are arranged vertically.
The project includes:

While creating this project, I practiced the following Flexbox properties:

* display: flex
* justify-content
* align-items
* flex-direction

I experimented with different values to understand how Flexbox changes the position and direction of elements.

How to Run

1. Download or clone the project.
2. Open the project folder.
3. Make sure index.html and style.css are in the same folder.
4. Open index.html in a web browser.

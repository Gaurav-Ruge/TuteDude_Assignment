This project is created using HTML and CSS. It demonstrates the use of different CSS selectors such as element, class, ID, and pseudo-class selectors to style headings, paragraphs, and lists.

How to Run
1. Download or clone the project.
2. Open the project folder.
3. Double-click `index.html` or open it in any web browser.